# CL-DQE 中文说明

本仓库给出论文 **“Research on English-Chinese semantic alignment and translation quality assessment based on cross-language contrastive representation learning”** 对应的 PyTorch 实现框架，包含 MSCLE、CCRL、ESA、LEA、MSQE 和 GQI 六个核心部分，以及 PAWS-X/WMT20 数据预处理、联合训练、测试、消融、复杂度统计和结果绘图代码。

需要强调：这是根据论文文字、公式和框架图整理出的 **paper-faithful implementation**，不是声称拿到了作者原始源代码。论文中没有明确给出的细节均放在 `docs/REPRODUCIBILITY.md` 中说明并做成可配置项。

## 推荐运行顺序

```bash
pip install -r requirements.txt
pip install -e .

python scripts/prepare_pawsx.py
python scripts/prepare_wmt20.py --src ... --mt ... --hter ... --split train
python scripts/prepare_wmt20.py --src ... --mt ... --hter ... --split dev
python scripts/prepare_wmt20.py --src ... --mt ... --hter ... --split test
python scripts/train_tokenizers.py
python train.py
python evaluate.py --split test
python benchmark.py
python plots/plot_results.py
```

## 论文与代码的对应关系

`MSCLEEncoder` 对应多尺度双通道跨语言编码；`ContrastiveProjector + contrastive_margin_loss` 对应 CCRL；`ESA` 对应显式语义对齐预测；`LEA` 对应局部错误感知；`MSQE` 对应充分性、流畅性、错误严重度和一致性四因子融合；`QualityGraph` 对应质量图神经网络推理。

## 公开 GitHub 前建议

请先阅读 `GITHUB_RELEASE_GUIDE_CN.md`，至少替换 `USERNAME`，核对作者信息、论文最终 DOI、许可证，并确认不要把数据集、超大 checkpoint、个人绝对路径和账号密钥提交到仓库。
