from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cldqe.model import CLDQE
from cldqe.losses import contrastive_margin_loss


def tiny_cfg():
    return {
        "en_vocab_size": 100,
        "zh_vocab_size": 120,
        "embedding_dim": 32,
        "gru_hidden": 16,
        "cnn_out_dim": 32,
        "error_dim": 24,
        "graph_dim": 16,
        "contrastive_dim": 12,
        "downsample_factor": 2,
        "dropout": 0.1,
        "max_length": 12,
        "margin": 0.2,
        "use_ccrl": True,
        "use_esa": True,
        "use_lea": True,
        "use_msqe": True,
        "use_gqi": True,
    }


def test_forward_shapes():
    model = CLDQE(tiny_cfg())
    en = torch.randint(1, 100, (4, 12))
    zh = torch.randint(1, 120, (4, 12))
    out = model(en, zh)
    assert out["align_prob"].shape == (4,)
    assert out["sim_score"].shape == (4,)
    assert out["factors"].shape == (4, 4)
    assert out["q_sent"].shape == (4,)
    assert out["q_graph"].shape == (4,)
    assert torch.isfinite(out["q_graph"]).all()


def test_contrastive_loss_is_finite():
    z1 = torch.nn.functional.normalize(torch.randn(4, 8), dim=-1)
    z2 = torch.nn.functional.normalize(torch.randn(4, 8), dim=-1)
    loss = contrastive_margin_loss(z1, z2, 0.2)
    assert loss.ndim == 0
    assert torch.isfinite(loss)
