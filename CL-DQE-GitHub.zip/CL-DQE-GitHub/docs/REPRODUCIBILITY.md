# Reproducibility notes

The code follows the manuscript where the design is explicit and exposes configuration switches where it is not.

## Directly specified by the manuscript

- English/Chinese semantic alignment + reference-free translation quality estimation in one model.
- MSCLE: fine-grained and coarse-grained BiGRU features plus CNN/dilated-convolution features.
- CCRL: cosine-similarity margin contrastive objective.
- ESA: interaction vector `[s_en, s_zh, s_en-s_zh, s_en*s_zh]`, alignment probability and similarity score.
- LEA: cross-language attention over fine-grained sequence representations.
- MSQE: four latent factors (adequacy, fluency, severity, consistency) fused with learnable softmax weights.
- GQI: graph reasoning over source, target, quality factors, local error, and final quality node.
- Embedding dimension 128, hidden dimension 256 in the paper's experimental description, CNN channels 64, Adam, LR 1e-3, batch size 16, maximum sentence length 50, early stopping, RTX 4080/PyTorch.

## Underspecified choices made explicit in this repository

1. **PAWS-X EN-ZH construction.** PAWS-X is multilingual, but the manuscript does not say exactly how English and Chinese sentences were paired. `prepare_pawsx.py` matches row-aligned EN and ZH configurations, using EN `sentence1` and ZH `sentence2` with the original paraphrase label.
2. **PAWS-X sample counts.** The public dataset contains more training examples than the manuscript's approximate 20k. The script defaults to 20k train and up to 2k dev/test with seed 42.
3. **WMT20 labels.** WMT20 sentence-level QE uses HTER. The manuscript calls the target a quality score. The config defaults to `q = 1 - HTER`; switch to `quality_target: hter` to predict HTER directly.
4. **Multi-factor supervision.** The manuscript does not provide separate labels for adequacy/fluency/severity/consistency. They are therefore implemented as latent sigmoid factors supervised only through the fused sentence/global quality losses.
5. **Quality graph edges.** Node types are specified but the adjacency matrix is not. This implementation uses a small fixed undirected graph connecting S/T to factors, T to local error, and factors/error to the final quality node, with self-loops and symmetric normalization.
6. **Downsampling factor, margin and loss weights.** Defaults are 2, 0.2 and 1.0 respectively and are all configurable.
7. **Graph depth.** The manuscript gives a one-layer GCN equation; this implementation uses one graph-convolution layer.

Because of these gaps, the repository should be described as a **paper-faithful implementation** rather than an author-verified exact reproduction unless the original training scripts and split files are available.
