# CL-DQE Model Card

## Intended use

Research on English-Chinese semantic alignment, sentence-pair semantic consistency, and reference-free machine translation quality estimation.

## Inputs / outputs

Input: an English source sentence and a Chinese candidate/translation. Output: semantic alignment probability, continuous semantic similarity, four latent quality factors, a sentence-level quality score, and a graph-refined global quality score.

## Training data

The manuscript reports PAWS-X En-Zh for semantic alignment and WMT20 En-Zh sentence-level QE for quality estimation. This repository does not bundle either dataset.

## Limitations

The exact PAWS-X cross-language pairing, WMT20 split files, quality-factor labels (if any), GQI adjacency, downsampling factor, contrastive margin, and multi-task loss weights are not fully specified in the manuscript. Results can therefore differ from the paper even with identical hardware.

## Ethical / practical note

The score is a model estimate, not a substitute for professional translation review. Performance should be validated on the target domain before deployment.
