# CL-DQE 发布 GitHub 操作说明

建议仓库名称：`CL-DQE`  
建议 Description：`Official/Paper-faithful PyTorch implementation of CL-DQE for English-Chinese semantic alignment and reference-free translation quality estimation.`

建议 Topics：`machine-translation`, `quality-estimation`, `cross-lingual`, `contrastive-learning`, `semantic-alignment`, `pytorch`, `graph-neural-network`, `nlp`

## 1. 发布前要修改

请先全局搜索并替换：

- `USERNAME` → 你的 GitHub 用户名/组织名；
- `CITATION.cff` 中论文年份、期刊、DOI（如果论文已经正式发表）；
- `README.md` 中的论文状态与引用格式；
- 如果你不想使用 MIT License，请在公开仓库前更换许可证。

## 2. 本地初始化

```bash
cd CL-DQE-GitHub
git init
git add .
git commit -m "Initial release of CL-DQE"
git branch -M main
git remote add origin https://github.com/USERNAME/CL-DQE.git
git push -u origin main
```

## 3. 建议的首个 Release

Tag：`v0.1.0`  
Title：`CL-DQE v0.1.0 - Initial Research Release`

Release notes：

```text
Initial research release of CL-DQE.

Included:
- PyTorch implementation of MSCLE, CCRL, ESA, LEA, MSQE and GQI;
- PAWS-X and WMT20 preprocessing utilities;
- joint multi-task training and evaluation scripts;
- ablation configuration generator;
- complexity benchmarking and plotting utilities;
- reproducibility notes documenting choices not fully specified in the manuscript.

Note: datasets and trained checkpoints are not redistributed in this release.
```

## 4. GitHub 页面建议

About 区域可填写：

```text
CL-DQE: Cross-language contrastive representation learning for English-Chinese semantic alignment and translation quality estimation.
```

建议勾选：`Releases`、`Issues`。如果暂时不接收外部修改，可先不开 `Discussions`。

## 5. 不建议直接上传

不要把 WMT20/PAWS-X 原始数据、训练缓存、几百 MB 的 checkpoint、个人绝对路径、审稿文件、未公开数据或账号密钥直接提交到 GitHub。`.gitignore` 已经默认排除了这些内容。
