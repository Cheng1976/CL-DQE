#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
import sys
import torch
from thop import profile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from cldqe.model import CLDQE
from cldqe.utils import resolve_device


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default="checkpoints/cl_dqe_best.pt")
    p.add_argument("--runs", type=int, default=200)
    args = p.parse_args()
    device = resolve_device("auto")
    ckpt = torch.load(args.checkpoint, map_location=device)
    model = CLDQE(ckpt["config"]["model"]).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    L = ckpt["config"]["model"]["max_length"]
    en = torch.randint(1, ckpt["config"]["model"]["en_vocab_size"], (1, L), device=device)
    zh = torch.randint(1, ckpt["config"]["model"]["zh_vocab_size"], (1, L), device=device)

    params = sum(p.numel() for p in model.parameters())
    try:
        macs, _ = profile(model, inputs=(en, zh), verbose=False)
        flops = 2 * macs
    except Exception:
        flops = None

    for _ in range(20):
        with torch.no_grad(): model(en, zh)
    if device.type == "cuda": torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(args.runs):
        with torch.no_grad(): model(en, zh)
    if device.type == "cuda": torch.cuda.synchronize()
    latency_ms = (time.perf_counter() - t0) * 1000 / args.runs
    memory_mb = None
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
        with torch.no_grad(): model(en, zh)
        memory_mb = torch.cuda.max_memory_allocated() / 1024**2

    res = {"params": params, "flops": flops, "latency_ms_b1": latency_ms, "peak_memory_mb": memory_mb, "device": str(device)}
    Path("results").mkdir(exist_ok=True)
    with open("results/complexity.json", "w") as f: json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
