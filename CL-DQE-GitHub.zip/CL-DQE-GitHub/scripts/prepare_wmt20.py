#!/usr/bin/env python
"""Convert WMT20 QE source/MT/HTER files into CL-DQE TSV format.

Run once for train/dev/test. Each input is one item per line. HTER must be normalized
into [0,1] or supplied with --hter-scale 100 for percentage-form labels.
"""

import argparse
from pathlib import Path
import pandas as pd


def read_lines(path):
    with open(path, "r", encoding="utf-8") as f:
        return [x.rstrip("\n") for x in f]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--src", required=True, help="English source text file")
    p.add_argument("--mt", required=True, help="Chinese MT output file")
    p.add_argument("--hter", required=True, help="Sentence-level HTER file")
    p.add_argument("--split", required=True, choices=["train", "dev", "test"])
    p.add_argument("--out-dir", default="data/processed")
    p.add_argument("--hter-scale", type=float, default=1.0)
    args = p.parse_args()

    src = read_lines(args.src)
    mt = read_lines(args.mt)
    hter = [float(x.strip()) / args.hter_scale for x in read_lines(args.hter)]
    if not (len(src) == len(mt) == len(hter)):
        raise ValueError(f"length mismatch: src={len(src)}, mt={len(mt)}, hter={len(hter)}")
    if not all(0.0 <= x <= 1.0 for x in hter):
        raise ValueError("HTER values must be in [0,1] after scaling.")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"wmt20_{args.split}.tsv"
    pd.DataFrame({"src": src, "tgt": mt, "hter": hter}).to_csv(path, sep="\t", index=False)
    print(f"saved {len(src):6d} rows -> {path}")


if __name__ == "__main__":
    main()
