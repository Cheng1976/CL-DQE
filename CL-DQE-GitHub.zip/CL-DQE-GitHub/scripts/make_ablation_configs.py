#!/usr/bin/env python
import copy
from pathlib import Path
import yaml

BASE = Path("configs/cl_dqe.yaml")
OUT = Path("configs/ablations")
OUT.mkdir(parents=True, exist_ok=True)
with open(BASE, "r", encoding="utf-8") as f:
    cfg = yaml.safe_load(f)

mapping = {
    "wo_ccrl": "use_ccrl",
    "wo_esa": "use_esa",
    "wo_lea": "use_lea",
    "wo_msqe": "use_msqe",
    "wo_gqi": "use_gqi",
}
for name, key in mapping.items():
    c = copy.deepcopy(cfg)
    c["model"][key] = False
    with open(OUT / f"{name}.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(c, f, sort_keys=False, allow_unicode=True)
    print(OUT / f"{name}.yaml")
