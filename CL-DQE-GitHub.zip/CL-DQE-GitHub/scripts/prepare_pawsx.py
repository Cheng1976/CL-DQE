#!/usr/bin/env python
"""Prepare English-Chinese PAWS-X pairs for the CL-DQE alignment task.

The manuscript does not specify the exact EN-ZH pair construction. This script uses
English sentence1 and its row-aligned Chinese sentence2, preserving the PAWS-X label.
Rows are kept in aligned order and then deterministically subsampled.
"""

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from datasets import load_dataset


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out-dir", default="data/processed")
    p.add_argument("--dataset", default="google-research-datasets/paws-x")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--train-limit", type=int, default=20000)
    p.add_argument("--dev-limit", type=int, default=2000)
    p.add_argument("--test-limit", type=int, default=2000)
    args = p.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    en = load_dataset(args.dataset, "en")
    zh = load_dataset(args.dataset, "zh")
    split_map = {"train": "train", "validation": "dev", "test": "test"}
    limits = {"train": args.train_limit, "validation": args.dev_limit, "test": args.test_limit}
    rng = np.random.default_rng(args.seed)

    for hf_split, name in split_map.items():
        n = min(len(en[hf_split]), len(zh[hf_split]))
        labels_en = np.asarray(en[hf_split]["label"][:n])
        labels_zh = np.asarray(zh[hf_split]["label"][:n])
        if not np.array_equal(labels_en, labels_zh):
            raise RuntimeError(f"EN/ZH labels are not row-aligned for split {hf_split}.")
        idx = np.arange(n)
        rng.shuffle(idx)
        idx = idx[: min(limits[hf_split], n)]
        rows = []
        for i in idx:
            rows.append({
                "src": en[hf_split][int(i)]["sentence1"],
                "tgt": zh[hf_split][int(i)]["sentence2"],
                "align_label": int(labels_en[i]),
                "sim_label": float(labels_en[i]),
            })
        df = pd.DataFrame(rows)
        path = out / f"pawsx_{name}.tsv"
        df.to_csv(path, sep="\t", index=False)
        print(f"saved {len(df):6d} rows -> {path}")


if __name__ == "__main__":
    main()
