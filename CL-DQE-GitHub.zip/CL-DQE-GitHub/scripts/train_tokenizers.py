#!/usr/bin/env python
"""Train the English subword tokenizer and Chinese character vocabulary."""

import argparse
from pathlib import Path
import sys
import pandas as pd
import sentencepiece as spm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cldqe.tokenization import build_zh_vocab


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--processed-dir", default="data/processed")
    p.add_argument("--out-dir", default="data/tokenizers")
    p.add_argument("--en-vocab-size", type=int, default=8000)
    p.add_argument("--zh-vocab-size", type=int, default=9000)
    args = p.parse_args()

    proc = Path(args.processed_dir)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    frames = []
    for name in ["pawsx_train.tsv", "wmt20_train.tsv"]:
        path = proc / name
        if path.exists():
            frames.append(pd.read_csv(path, sep="\t"))
    if not frames:
        raise FileNotFoundError("No training TSV files found. Prepare PAWS-X/WMT20 first.")
    df = pd.concat(frames, ignore_index=True)

    en_txt = out / "english_corpus.txt"
    with open(en_txt, "w", encoding="utf-8") as f:
        for s in df["src"].astype(str):
            f.write(s.lower().replace("\n", " ") + "\n")

    # +1 is reserved by our wrapper for padding ID 0.
    spm.SentencePieceTrainer.train(
        input=str(en_txt),
        model_prefix=str(out / "en_spm"),
        vocab_size=args.en_vocab_size - 1,
        model_type="bpe",
        character_coverage=1.0,
        unk_id=0,
        bos_id=-1,
        eos_id=-1,
        pad_id=-1,
    )
    build_zh_vocab(df["tgt"].astype(str), out / "zh_vocab.json", args.zh_vocab_size)
    en_txt.unlink(missing_ok=True)
    print(f"tokenizers written to {out}")


if __name__ == "__main__":
    main()
