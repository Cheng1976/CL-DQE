# Contributing

Issues and pull requests are welcome. For model changes, please include: (1) the exact configuration, (2) dataset split information, (3) random seed, and (4) validation metrics. Please keep public datasets out of the repository and add only scripts that download or preprocess them according to their licenses.
