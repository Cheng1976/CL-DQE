#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from cldqe.model import CLDQE
from cldqe.tokenization import EnglishSentencePiece, ChineseCharTokenizer
from cldqe.utils import resolve_device


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default="checkpoints/cl_dqe_best.pt")
    p.add_argument("--src", required=True, help="English source sentence")
    p.add_argument("--tgt", required=True, help="Chinese translation/candidate")
    args = p.parse_args()

    device = resolve_device("auto")
    ckpt = torch.load(args.checkpoint, map_location=device)
    cfg = ckpt["config"]
    tok_dir = Path(cfg["data"]["tokenizer_dir"])
    en_tok = EnglishSentencePiece(tok_dir / "en_spm.model")
    zh_tok = ChineseCharTokenizer(tok_dir / "zh_vocab.json")
    max_len = cfg["model"]["max_length"]
    en = torch.tensor([en_tok.encode(args.src, max_len)], device=device)
    zh = torch.tensor([zh_tok.encode(args.tgt, max_len)], device=device)
    model = CLDQE(cfg["model"]).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    with torch.no_grad():
        o = model(en, zh)
    print(f"alignment_probability = {o['align_prob'].item():.4f}")
    print(f"semantic_similarity   = {o['sim_score'].item():.4f}")
    print(f"sentence_quality      = {o['q_sent'].item():.4f}")
    print(f"graph_quality         = {o['q_graph'].item():.4f}")
    print("factors [AD, FL, SV, CS] =", [round(x, 4) for x in o["factors"][0].tolist()])


if __name__ == "__main__":
    main()
