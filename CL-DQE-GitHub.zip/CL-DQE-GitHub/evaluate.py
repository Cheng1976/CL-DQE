#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from cldqe.data import PairDataset, required_paths
from cldqe.metrics import alignment_metrics, qe_metrics
from cldqe.model import CLDQE
from cldqe.tokenization import EnglishSentencePiece, ChineseCharTokenizer
from cldqe.utils import resolve_device


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default="checkpoints/cl_dqe_best.pt")
    p.add_argument("--split", default="test", choices=["dev", "test"])
    p.add_argument("--out-dir", default="results")
    args = p.parse_args()

    device = resolve_device("auto")
    ckpt = torch.load(args.checkpoint, map_location=device)
    cfg = ckpt["config"]
    tok_dir = Path(cfg["data"]["tokenizer_dir"])
    en_tok = EnglishSentencePiece(tok_dir / "en_spm.model")
    zh_tok = ChineseCharTokenizer(tok_dir / "zh_vocab.json")
    model = CLDQE(cfg["model"]).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()

    paths = required_paths(cfg["data"]["processed_dir"])
    pa_path = paths[f"paws_{args.split}"]
    qe_path = paths[f"wmt_{args.split}"]
    max_len = cfg["model"]["max_length"]
    pa = PairDataset(pa_path, en_tok, zh_tok, max_len, "align")
    qe = PairDataset(qe_path, en_tok, zh_tok, max_len, "qe", cfg["data"]["quality_target"])
    pa_loader = DataLoader(pa, batch_size=cfg["training"]["batch_size"])
    qe_loader = DataLoader(qe, batch_size=cfg["training"]["batch_size"])

    ay, ap, sy = [], [], []
    with torch.no_grad():
        for b in pa_loader:
            ids = [b[x].to(device) for x in ["en_ids", "zh_ids", "en_mask", "zh_mask"]]
            o = model(*ids)
            ay += b["align"].numpy().tolist()
            ap += o["align_prob"].cpu().numpy().tolist()
            sy += o["sim_score"].cpu().numpy().tolist()

    qy, qp, qs = [], [], []
    factors = []
    with torch.no_grad():
        for b in qe_loader:
            ids = [b[x].to(device) for x in ["en_ids", "zh_ids", "en_mask", "zh_mask"]]
            o = model(*ids)
            qy += b["quality"].numpy().tolist()
            qp += o["q_graph"].cpu().numpy().tolist()
            qs += o["q_sent"].cpu().numpy().tolist()
            factors.extend(o["factors"].cpu().numpy().tolist())

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"label": ay, "align_prob": ap, "sim_score": sy}).to_csv(out / f"alignment_{args.split}.csv", index=False)
    fdf = pd.DataFrame(factors, columns=["adequacy", "fluency", "severity", "consistency"])
    qdf = pd.DataFrame({"target": qy, "q_sent": qs, "q_graph": qp})
    pd.concat([qdf, fdf], axis=1).to_csv(out / f"qe_{args.split}.csv", index=False)
    metrics = {"alignment": alignment_metrics(ay, ap), "qe": qe_metrics(qy, qp)}
    with open(out / f"metrics_{args.split}.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
