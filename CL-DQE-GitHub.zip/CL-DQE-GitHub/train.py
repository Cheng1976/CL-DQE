#!/usr/bin/env python
from __future__ import annotations

import argparse
import csv
from itertools import cycle
from pathlib import Path
import sys

import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from cldqe.config import load_config
from cldqe.data import PairDataset, required_paths
from cldqe.losses import compute_alignment_losses, compute_qe_losses
from cldqe.metrics import alignment_metrics, qe_metrics
from cldqe.model import CLDQE
from cldqe.tokenization import EnglishSentencePiece, ChineseCharTokenizer
from cldqe.utils import resolve_device, set_seed


def move(batch, device):
    return {k: v.to(device) if torch.is_tensor(v) else v for k, v in batch.items()}


@torch.no_grad()
def evaluate_alignment(model, loader, device):
    model.eval()
    ys, ps = [], []
    for b in loader:
        b = move(b, device)
        o = model(b["en_ids"], b["zh_ids"], b["en_mask"], b["zh_mask"])
        ys.extend(b["align"].cpu().numpy().tolist())
        ps.extend(o["align_prob"].cpu().numpy().tolist())
    return alignment_metrics(ys, ps)


@torch.no_grad()
def evaluate_qe(model, loader, device):
    model.eval()
    ys, ps = [], []
    for b in loader:
        b = move(b, device)
        o = model(b["en_ids"], b["zh_ids"], b["en_mask"], b["zh_mask"])
        ys.extend(b["quality"].cpu().numpy().tolist())
        ps.extend(o["q_graph"].cpu().numpy().tolist())
    return qe_metrics(ys, ps)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/cl_dqe.yaml")
    p.add_argument("--output", default="checkpoints/cl_dqe_best.pt")
    p.add_argument("--log", default="results/train_log.csv")
    args = p.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    device = resolve_device(cfg["training"].get("device", "auto"))
    paths = required_paths(cfg["data"]["processed_dir"])
    tok_dir = Path(cfg["data"]["tokenizer_dir"])
    en_tok = EnglishSentencePiece(tok_dir / "en_spm.model")
    zh_tok = ChineseCharTokenizer(tok_dir / "zh_vocab.json")
    cfg["model"]["en_vocab_size"] = en_tok.vocab_size
    cfg["model"]["zh_vocab_size"] = zh_tok.vocab_size

    max_len = cfg["model"]["max_length"]
    q_target = cfg["data"]["quality_target"]
    ds = {
        "pa_train": PairDataset(paths["paws_train"], en_tok, zh_tok, max_len, "align"),
        "pa_dev": PairDataset(paths["paws_dev"], en_tok, zh_tok, max_len, "align"),
        "qe_train": PairDataset(paths["wmt_train"], en_tok, zh_tok, max_len, "qe", q_target),
        "qe_dev": PairDataset(paths["wmt_dev"], en_tok, zh_tok, max_len, "qe", q_target),
    }
    t = cfg["training"]
    loader = {
        k: DataLoader(v, batch_size=t["batch_size"], shuffle=k.endswith("train"),
                      num_workers=t["num_workers"], drop_last=k.endswith("train"))
        for k, v in ds.items()
    }

    model = CLDQE(cfg["model"]).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=t["lr"], weight_decay=t["weight_decay"])
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    log_path = Path(args.log)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    best, bad = -float("inf"), 0
    fields = ["epoch", "train_loss", "val_acc", "val_f1", "val_mae", "val_rmse", "val_pearson"]
    with open(log_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()

        for epoch in range(1, t["epochs"] + 1):
            model.train()
            n_steps = max(len(loader["pa_train"]), len(loader["qe_train"]))
            pa_iter = cycle(loader["pa_train"])
            qe_iter = cycle(loader["qe_train"])
            running = 0.0
            bar = tqdm(range(n_steps), desc=f"epoch {epoch:03d}")
            for _ in bar:
                pa = move(next(pa_iter), device)
                qe = move(next(qe_iter), device)
                opt.zero_grad(set_to_none=True)

                opa = model(pa["en_ids"], pa["zh_ids"], pa["en_mask"], pa["zh_mask"])
                lpa = compute_alignment_losses(
                    opa, pa, cfg["model"]["margin"], model.use_ccrl, model.use_esa
                )
                oqe = model(qe["en_ids"], qe["zh_ids"], qe["en_mask"], qe["zh_mask"])
                lqe = compute_qe_losses(
                    oqe, qe["quality"], cfg["model"]["margin"],
                    model.use_ccrl, model.use_msqe, model.use_gqi
                )
                loss = (
                    lpa["cl"] + t["lambda_align"] * lpa["align"] + t["lambda_sim"] * lpa["sim"]
                    + lqe["cl"] + t["lambda_sent"] * lqe["sent"] + t["lambda_graph"] * lqe["graph"]
                )
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), t["grad_clip"])
                opt.step()
                running += float(loss.item())
                bar.set_postfix(loss=f"{running / (_ + 1):.4f}")

            am = evaluate_alignment(model, loader["pa_dev"], device)
            qm = evaluate_qe(model, loader["qe_dev"], device)
            score = am["f1"] + (qm["pearson"] if np.isfinite(qm["pearson"]) else -1.0)
            row = {
                "epoch": epoch, "train_loss": running / n_steps,
                "val_acc": am["acc"], "val_f1": am["f1"],
                "val_mae": qm["mae"], "val_rmse": qm["rmse"], "val_pearson": qm["pearson"],
            }
            writer.writerow(row)
            f.flush()
            print(row)

            if score > best:
                best, bad = score, 0
                torch.save({"model": model.state_dict(), "config": cfg}, out_path)
                print(f"saved best -> {out_path}")
            else:
                bad += 1
                if bad >= t["patience"]:
                    print("early stopping")
                    break


if __name__ == "__main__":
    main()
