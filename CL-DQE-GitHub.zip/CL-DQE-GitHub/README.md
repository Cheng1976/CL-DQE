# CL-DQE

PyTorch implementation of **CL-DQE**, a cross-language contrastive representation framework for **English-Chinese semantic alignment** and **reference-free translation quality estimation**.

> Repository status: paper-faithful implementation prepared from the manuscript. It is **not claimed to be the authors' original training code**. Choices that are not fully specified in the paper are documented in `docs/REPRODUCIBILITY.md`.

## Overview

CL-DQE jointly models two tasks:

1. semantic alignment recognition for an English-Chinese sentence pair;
2. sentence-level machine translation quality estimation without a human reference translation.

The implementation contains the six model components described in the paper:

- **MSCLE** — multi-scale cross-language encoder using fine/coarse BiGRU representations plus CNN/dilated-convolution local features;
- **CCRL** — cross-language contrastive representation learning with a cosine-similarity margin loss;
- **ESA** — explicit semantic alignment prediction with binary alignment and continuous similarity heads;
- **LEA** — local error-aware cross-language attention;
- **MSQE** — four-factor sentence-level quality estimation for adequacy, fluency, severity and consistency;
- **GQI** — quality graph inference over source, target, factor, local-error and final-quality nodes.

## Repository structure

```text
CL-DQE/
├── configs/
│   └── cl_dqe.yaml
├── data/
│   └── README.md
├── docs/
│   ├── MODEL_CARD.md
│   └── REPRODUCIBILITY.md
├── plots/
│   └── plot_results.py
├── scripts/
│   ├── prepare_pawsx.py
│   ├── prepare_wmt20.py
│   ├── train_tokenizers.py
│   └── make_ablation_configs.py
├── src/cldqe/
│   ├── data.py
│   ├── losses.py
│   ├── metrics.py
│   ├── model.py
│   ├── modules.py
│   ├── tokenization.py
│   └── utils.py
├── tests/
│   └── test_smoke.py
├── train.py
├── evaluate.py
├── predict.py
├── benchmark.py
├── requirements.txt
├── CITATION.cff
└── LICENSE
```

## Installation

Python 3.10+ is recommended.

```bash
git clone https://github.com/USERNAME/CL-DQE.git
cd CL-DQE
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
pip install -e .
```

## Data preparation

The manuscript reports **PAWS-X En-Zh** for semantic alignment and **WMT20 En-Zh sentence-level QE** for translation quality estimation. The repository intentionally does not redistribute those datasets.

### 1. PAWS-X

The manuscript does not fully specify how English and Chinese rows are combined into a cross-language pair. This implementation makes the choice explicit: it aligns the English and Chinese PAWS-X configurations by row, uses English `sentence1` as source and Chinese `sentence2` as target, and keeps the original paraphrase label.

```bash
python scripts/prepare_pawsx.py \
  --out-dir data/processed \
  --train-limit 20000 \
  --dev-limit 2000 \
  --test-limit 2000
```

### 2. WMT20 QE

Download the official WMT20 English-Chinese QE data, then convert its source, MT and sentence-level HTER files:

```bash
python scripts/prepare_wmt20.py \
  --src /path/to/train.src \
  --mt /path/to/train.mt \
  --hter /path/to/train.hter \
  --split train

python scripts/prepare_wmt20.py --src /path/to/dev.src --mt /path/to/dev.mt --hter /path/to/dev.hter --split dev
python scripts/prepare_wmt20.py --src /path/to/test.src --mt /path/to/test.mt --hter /path/to/test.hter --split test
```

If HTER is stored as percentages, add `--hter-scale 100`.

### 3. Train tokenizers

The paper uses lowercased English subwords, Chinese character-level tokenization, vocabulary sizes around 8,000/9,000, and maximum sequence length 50. This repository uses SentencePiece BPE for English and a frequency-based character vocabulary for Chinese.

```bash
python scripts/train_tokenizers.py
```

## Training

The default configuration follows the manuscript where values are available: embedding dimension 128, BiGRU hidden size 128 per direction, Adam, learning rate `1e-3`, batch size 16, maximum length 50, dropout and early stopping.

```bash
python train.py --config configs/cl_dqe.yaml
```

The best checkpoint is written to:

```text
checkpoints/cl_dqe_best.pt
```

Training history is written to:

```text
results/train_log.csv
```

## Evaluation

```bash
python evaluate.py --checkpoint checkpoints/cl_dqe_best.pt --split test
```

Outputs include:

```text
results/alignment_test.csv
results/qe_test.csv
results/metrics_test.json
```

Alignment metrics: Accuracy, Precision, Recall, F1 and ROC-AUC.  
QE metrics: MAE, MSE, RMSE and Pearson correlation.

## Inference

```bash
python predict.py \
  --checkpoint checkpoints/cl_dqe_best.pt \
  --src "The aircraft completed the inspection successfully." \
  --tgt "该飞机成功完成了检查。"
```

Example output fields:

```text
alignment_probability
semantic_similarity
sentence_quality
graph_quality
factors [AD, FL, SV, CS]
```

## Ablation study

Generate five ablation configurations corresponding to removing CCRL, ESA, LEA, MSQE and GQI:

```bash
python scripts/make_ablation_configs.py
```

Then run, for example:

```bash
python train.py --config configs/ablations/wo_ccrl.yaml --output checkpoints/wo_ccrl.pt --log results/wo_ccrl.csv
```

## Complexity benchmark

```bash
python benchmark.py --checkpoint checkpoints/cl_dqe_best.pt
```

The script reports parameter count, approximate FLOPs, batch-1 inference latency and peak CUDA memory when a GPU is available.

## Plotting

After evaluation and benchmarking:

```bash
python plots/plot_results.py --results results --split test
```

Figures are saved under `results/figures/`.

## Important reproducibility note

Several implementation-critical items are not fully defined in the manuscript: exact PAWS-X EN-ZH pair construction, exact WMT20 split files, supervision of the four quality factors, quality-graph adjacency, downsampling factor, contrastive margin and individual loss weights. This repository therefore exposes these as explicit choices instead of silently hard-coding unverifiable assumptions. See `docs/REPRODUCIBILITY.md` before reporting reproduced numbers.

## Expected paper-reported metrics

The manuscript reports the following CL-DQE results as reference targets, not guaranteed outputs of this reimplementation:

| Task | Metrics reported in manuscript |
|---|---|
| Semantic alignment | ACC 0.918, Precision 0.915, Recall 0.910, F1 0.912 |
| Translation QE | MAE 0.103, MSE 0.0219, RMSE 0.148, Pearson 0.913 |

Because the manuscript contains some result-table inconsistencies and leaves several training details unspecified, do not treat exact numeric matching as a requirement until the original split files and training configuration are confirmed.

## Citation

If this code is used in academic work, cite the associated manuscript:

```bibtex
@article{cheng2026cldqe,
  title   = {Research on English-Chinese semantic alignment and translation quality assessment based on cross-language contrastive representation learning},
  author  = {Cheng, Shufang and Zhang, Guimei},
  year    = {2026}
}
```

Update the citation with the final journal/DOI after publication.

## License

Code in this repository is released under the MIT License. Dataset licenses remain with their original providers.
