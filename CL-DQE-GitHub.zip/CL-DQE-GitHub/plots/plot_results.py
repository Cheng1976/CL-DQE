#!/usr/bin/env python
"""Generate paper-style result figures from training/evaluation CSV files."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve


def save_train(log, out):
    df = pd.read_csv(log)
    for col, ylabel in [("train_loss", "Loss"), ("val_acc", "ACC"), ("val_f1", "F1"), ("val_pearson", "Pearson")]:
        if col not in df:
            continue
        fig, ax = plt.subplots(figsize=(5, 4))
        ax.plot(df["epoch"], df[col], linewidth=1.6)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(out / f"curve_{col}.png", dpi=300)
        plt.close(fig)


def save_alignment(csv_path, out):
    df = pd.read_csv(csv_path)
    fpr, tpr, _ = roc_curve(df["label"], df["align_prob"])
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.plot(fpr, tpr, linewidth=1.8, label="CL-DQE")
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1)
    ax.set_xlabel("FPR")
    ax.set_ylabel("TPR")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out / "roc_cldqe.png", dpi=300)
    plt.close(fig)


def save_qe(csv_path, out):
    df = pd.read_csv(csv_path)
    err = np.abs(df["q_graph"].to_numpy() - df["target"].to_numpy())
    fig, ax = plt.subplots(figsize=(4.8, 4))
    ax.boxplot([err], labels=["CL-DQE"], showfliers=True)
    ax.set_ylabel("Absolute error")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out / "qe_error_boxplot.png", dpi=300)
    plt.close(fig)

    x = np.sort(err)
    y = np.arange(1, len(x) + 1) / len(x)
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.plot(x, y, linewidth=1.8, label="CL-DQE")
    ax.set_xlabel("Absolute error")
    ax.set_ylabel("CDF")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out / "qe_error_cdf.png", dpi=300)
    plt.close(fig)

    cols = ["q_graph", "adequacy", "fluency", "severity", "consistency"]
    corr = df[cols].corr().to_numpy()
    fig, ax = plt.subplots(figsize=(5.5, 4.8))
    im = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm")
    ax.set_xticks(range(len(cols)), cols, rotation=35, ha="right")
    ax.set_yticks(range(len(cols)), cols)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax.text(j, i, f"{corr[i,j]:.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(out / "quality_factor_correlation.png", dpi=300)
    plt.close(fig)


def save_complexity(json_path, out):
    if not Path(json_path).exists():
        return
    d = json.load(open(json_path, "r", encoding="utf-8"))
    keys = ["params", "flops", "latency_ms_b1", "peak_memory_mb"]
    vals = [d.get(k) for k in keys]
    labels = ["Params", "FLOPs", "Latency (ms)", "Memory (MB)"]
    for label, key, val in zip(labels, keys, vals):
        if val is None:
            continue
        fig, ax = plt.subplots(figsize=(4, 3.5))
        ax.bar(["CL-DQE"], [val])
        ax.set_ylabel(label)
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(out / f"complexity_{key}.png", dpi=300)
        plt.close(fig)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results", default="results")
    p.add_argument("--split", default="test")
    args = p.parse_args()
    r = Path(args.results)
    out = r / "figures"
    out.mkdir(parents=True, exist_ok=True)
    if (r / "train_log.csv").exists(): save_train(r / "train_log.csv", out)
    if (r / f"alignment_{args.split}.csv").exists(): save_alignment(r / f"alignment_{args.split}.csv", out)
    if (r / f"qe_{args.split}.csv").exists(): save_qe(r / f"qe_{args.split}.csv", out)
    save_complexity(r / "complexity.json", out)
    print(f"figures -> {out}")


if __name__ == "__main__":
    main()
