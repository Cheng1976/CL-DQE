from __future__ import annotations

import numpy as np
from scipy.stats import pearsonr
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score


def alignment_metrics(y_true, y_prob):
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob)
    y_pred = (y_prob >= 0.5).astype(int)
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="binary", zero_division=0)
    out = {
        "acc": float(accuracy_score(y_true, y_pred)),
        "precision": float(p),
        "recall": float(r),
        "f1": float(f1),
    }
    if len(np.unique(y_true)) == 2:
        out["auc"] = float(roc_auc_score(y_true, y_prob))
    return out


def qe_metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    diff = y_pred - y_true
    mse = float(np.mean(diff ** 2))
    if len(y_true) > 1 and np.std(y_true) > 0 and np.std(y_pred) > 0:
        pearson = float(pearsonr(y_true, y_pred)[0])
    else:
        pearson = float("nan")
    return {
        "mae": float(np.mean(np.abs(diff))),
        "mse": mse,
        "rmse": float(np.sqrt(mse)),
        "pearson": pearson,
    }
