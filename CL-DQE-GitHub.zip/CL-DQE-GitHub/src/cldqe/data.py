from __future__ import annotations

from pathlib import Path
import pandas as pd
import torch
from torch.utils.data import Dataset


class PairDataset(Dataset):
    def __init__(self, path, en_tok, zh_tok, max_length=50, task="align", quality_target="one_minus_hter"):
        self.df = pd.read_csv(path, sep="\t")
        self.en_tok = en_tok
        self.zh_tok = zh_tok
        self.max_length = max_length
        self.task = task
        self.quality_target = quality_target

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        r = self.df.iloc[idx]
        en = torch.tensor(self.en_tok.encode(str(r["src"]), self.max_length), dtype=torch.long)
        zh = torch.tensor(self.zh_tok.encode(str(r["tgt"]), self.max_length), dtype=torch.long)
        item = {
            "en_ids": en,
            "zh_ids": zh,
            "en_mask": (en != 0).long(),
            "zh_mask": (zh != 0).long(),
        }
        if self.task == "align":
            item["align"] = torch.tensor(float(r["align_label"]), dtype=torch.float32)
            item["sim"] = torch.tensor(float(r.get("sim_label", r["align_label"])), dtype=torch.float32)
        else:
            hter = float(r["hter"])
            q = 1.0 - hter if self.quality_target == "one_minus_hter" else hter
            item["quality"] = torch.tensor(q, dtype=torch.float32)
        return item


def required_paths(root):
    root = Path(root)
    return {
        "paws_train": root / "pawsx_train.tsv",
        "paws_dev": root / "pawsx_dev.tsv",
        "paws_test": root / "pawsx_test.tsv",
        "wmt_train": root / "wmt20_train.tsv",
        "wmt_dev": root / "wmt20_dev.tsv",
        "wmt_test": root / "wmt20_test.tsv",
    }
