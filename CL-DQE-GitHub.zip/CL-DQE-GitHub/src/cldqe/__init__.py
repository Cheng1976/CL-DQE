"""CL-DQE: cross-language semantic alignment and translation quality estimation."""

from .model import CLDQE

__all__ = ["CLDQE"]
__version__ = "0.1.0"
