from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
import re
import sentencepiece as spm

PAD = "<pad>"
UNK = "<unk>"


class EnglishSentencePiece:
    def __init__(self, model_file):
        self.sp = spm.SentencePieceProcessor(model_file=str(model_file))

    def encode(self, text, max_length=50):
        ids = self.sp.encode(text.lower(), out_type=int)
        # Reserve 0 for padding; SentencePiece unk/bos/eos ids are shifted by +1.
        ids = [i + 1 for i in ids[:max_length]]
        return ids + [0] * (max_length - len(ids))

    @property
    def vocab_size(self):
        return self.sp.get_piece_size() + 1


class ChineseCharTokenizer:
    def __init__(self, vocab_file):
        with open(vocab_file, "r", encoding="utf-8") as f:
            self.vocab = json.load(f)
        self.unk_id = self.vocab.get(UNK, 1)

    @staticmethod
    def chars(text):
        return [c for c in re.sub(r"\s+", "", str(text)) if c.strip()]

    def encode(self, text, max_length=50):
        ids = [self.vocab.get(c, self.unk_id) for c in self.chars(text)[:max_length]]
        return ids + [0] * (max_length - len(ids))

    @property
    def vocab_size(self):
        return len(self.vocab)


def build_zh_vocab(texts, out_file, max_size=9000):
    cnt = Counter()
    for t in texts:
        cnt.update(ChineseCharTokenizer.chars(t))
    vocab = {PAD: 0, UNK: 1}
    for ch, _ in cnt.most_common(max_size - 2):
        vocab[ch] = len(vocab)
    Path(out_file).parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(vocab, f, ensure_ascii=False, indent=2)
    return vocab
