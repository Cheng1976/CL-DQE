from __future__ import annotations

import torch
import torch.nn.functional as F


def contrastive_margin_loss(z_en, z_zh, margin=0.2, positive_mask=None):
    """Paper Eq. (21): max(0, m + M_ij - M_ii), j != i.

    positive_mask can exclude diagonal pairs that are known non-aligned (e.g. PAWS-X label 0).
    """
    b = z_en.size(0)
    if b < 2:
        return z_en.sum() * 0.0
    sim = z_en @ z_zh.t()
    diag = sim.diag().unsqueeze(1)
    loss_mat = F.relu(margin + sim - diag)
    offdiag = ~torch.eye(b, dtype=torch.bool, device=sim.device)
    valid = offdiag
    if positive_mask is not None:
        valid = valid & positive_mask.bool().unsqueeze(1)
    vals = loss_mat[valid]
    return vals.mean() if vals.numel() else sim.sum() * 0.0


def compute_alignment_losses(outputs, labels, margin=0.2, use_ccrl=True, use_esa=True):
    zero = outputs["q_graph"].sum() * 0.0
    cl = (
        contrastive_margin_loss(
            outputs["z_en"], outputs["z_zh"], margin, labels["align"] > 0.5
        )
        if use_ccrl
        else zero
    )
    if use_esa:
        align = F.binary_cross_entropy(outputs["align_prob"], labels["align"].float())
        sim = F.mse_loss(outputs["sim_score"], labels["sim"].float())
    else:
        align = sim = zero
    return {"cl": cl, "align": align, "sim": sim}


def compute_qe_losses(outputs, quality, margin=0.2, use_ccrl=True, use_msqe=True, use_gqi=True):
    zero = outputs["q_graph"].sum() * 0.0
    cl = contrastive_margin_loss(outputs["z_en"], outputs["z_zh"], margin) if use_ccrl else zero
    sent = F.mse_loss(outputs["q_sent"], quality.float()) if use_msqe else zero
    graph = F.mse_loss(outputs["q_graph"], quality.float()) if use_gqi else F.mse_loss(outputs["q_sent"], quality.float())
    return {"cl": cl, "sent": sent, "graph": graph}
