from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """Mean pool [B,L,D] using a boolean/0-1 mask [B,L]."""
    m = mask.float().unsqueeze(-1)
    denom = m.sum(dim=1).clamp_min(1.0)
    return (x * m).sum(dim=1) / denom


def downsample_mean(x: torch.Tensor, mask: torch.Tensor, factor: int):
    """Equation (14)-style fixed-step mean downsampling."""
    if factor <= 1:
        return x, mask
    b, l, d = x.shape
    pad = (factor - (l % factor)) % factor
    if pad:
        x = F.pad(x, (0, 0, 0, pad))
        mask = F.pad(mask, (0, pad), value=0)
    l2 = x.size(1) // factor
    x = x.view(b, l2, factor, d)
    m = mask.view(b, l2, factor).float()
    denom = m.sum(dim=2, keepdim=True).clamp_min(1.0)
    x = (x * m.unsqueeze(-1)).sum(dim=2) / denom
    new_mask = (m.sum(dim=2) > 0).long()
    return x, new_mask


class MSCLEEncoder(nn.Module):
    """Multi-scale cross-language encoder (MSCLE).

    The implementation follows the paper's text and Figure 1:
    fine BiGRU + coarse BiGRU + CNN/dilated-convolution local branch.
    """

    def __init__(
        self,
        embedding_dim=128,
        gru_hidden=128,
        cnn_out_dim=256,
        downsample_factor=2,
        dropout=0.2,
    ):
        super().__init__()
        self.downsample_factor = downsample_factor
        self.fine_gru = nn.GRU(
            embedding_dim, gru_hidden, batch_first=True, bidirectional=True
        )
        self.coarse_gru = nn.GRU(
            embedding_dim, gru_hidden, batch_first=True, bidirectional=True
        )
        self.cnn = nn.Sequential(
            nn.Conv1d(embedding_dim, 32, kernel_size=5, padding=2),
            nn.BatchNorm1d(32),
            nn.LeakyReLU(0.2),
            nn.Conv1d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(0.2),
            nn.Conv1d(64, 128, kernel_size=1),
            nn.LeakyReLU(0.2),
            nn.Conv1d(128, cnn_out_dim, kernel_size=3, padding=2, dilation=2),
            nn.LeakyReLU(0.2),
        )
        self.dropout = nn.Dropout(dropout)
        self.seq_dim = 2 * gru_hidden
        self.sent_dim = 2 * gru_hidden + 2 * gru_hidden + cnn_out_dim

    def forward(self, emb: torch.Tensor, mask: torch.Tensor):
        fine_seq, _ = self.fine_gru(emb)
        fine_vec = masked_mean(fine_seq, mask)

        coarse_emb, coarse_mask = downsample_mean(
            emb, mask, self.downsample_factor
        )
        coarse_seq, _ = self.coarse_gru(coarse_emb)
        coarse_vec = masked_mean(coarse_seq, coarse_mask)

        cnn_seq = self.cnn(emb.transpose(1, 2)).transpose(1, 2)
        cnn_mask = mask.bool().unsqueeze(-1)
        cnn_seq = cnn_seq.masked_fill(~cnn_mask, float("-inf"))
        cnn_vec = cnn_seq.max(dim=1).values
        cnn_vec = torch.where(torch.isfinite(cnn_vec), cnn_vec, torch.zeros_like(cnn_vec))

        sent = torch.cat([fine_vec, coarse_vec, cnn_vec], dim=-1)
        return {
            "fine_seq": self.dropout(fine_seq),
            "fine_vec": self.dropout(fine_vec),
            "coarse_vec": self.dropout(coarse_vec),
            "cnn_vec": self.dropout(cnn_vec),
            "sent": self.dropout(sent),
        }


class ContrastiveProjector(nn.Module):
    def __init__(self, in_dim: int, out_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, out_dim),
        )

    def forward(self, x):
        return F.normalize(self.net(x), dim=-1)


class ESA(nn.Module):
    """Explicit semantic alignment module."""

    def __init__(self, sent_dim: int, dropout: float = 0.2):
        super().__init__()
        self.interaction_dim = sent_dim * 4
        self.shared = nn.Sequential(
            nn.Linear(self.interaction_dim, 256), nn.ReLU(), nn.Dropout(dropout)
        )
        self.align = nn.Linear(256, 1)
        self.sim = nn.Linear(256, 1)

    @staticmethod
    def interaction(s_en, s_zh):
        return torch.cat([s_en, s_zh, s_en - s_zh, s_en * s_zh], dim=-1)

    def forward(self, s_en, s_zh):
        u = self.interaction(s_en, s_zh)
        h = self.shared(u)
        align = torch.sigmoid(self.align(h)).squeeze(-1)
        sim = torch.sigmoid(self.sim(h)).squeeze(-1)
        return u, align, sim


class LEA(nn.Module):
    """Local error-aware module with cross-language attention."""

    def __init__(self, seq_dim: int, error_dim: int = 256, dropout: float = 0.2):
        super().__init__()
        self.seq_dim = seq_dim
        self.proj = nn.Sequential(
            nn.Linear(seq_dim * 3, error_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, h_en, h_zh, mask_en, mask_zh):
        scores = torch.matmul(h_zh, h_en.transpose(1, 2)) / math.sqrt(self.seq_dim)
        scores = scores.masked_fill(~mask_en.bool().unsqueeze(1), -1e4)
        attn = torch.softmax(scores, dim=-1)
        aligned = torch.matmul(attn, h_en)
        d = torch.cat([h_zh, aligned, aligned - h_zh], dim=-1)
        err_seq = self.proj(d)
        err_vec = masked_mean(err_seq, mask_zh)
        return err_vec, attn


class MSQE(nn.Module):
    """Multi-factor sentence-level quality estimation."""

    def __init__(self, in_dim: int, dropout: float = 0.2):
        super().__init__()
        self.factor_net = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 4),
        )
        self.factor_logits = nn.Parameter(torch.zeros(4))

    def forward(self, x):
        factors = torch.sigmoid(self.factor_net(x))
        alpha = torch.softmax(self.factor_logits, dim=0)
        q_sent = (factors * alpha.unsqueeze(0)).sum(dim=-1)
        return factors, alpha, q_sent


class QualityGraph(nn.Module):
    """Small quality graph with S,T,F1..F4,E,L nodes and one GCN layer."""

    def __init__(self, sent_dim: int, error_dim: int, graph_dim: int = 128):
        super().__init__()
        self.src_proj = nn.Linear(sent_dim, graph_dim)
        self.tgt_proj = nn.Linear(sent_dim, graph_dim)
        self.factor_proj = nn.Linear(1, graph_dim)
        self.error_proj = nn.Linear(error_dim, graph_dim)
        self.quality_seed = nn.Parameter(torch.zeros(graph_dim))
        self.gcn = nn.Linear(graph_dim, graph_dim, bias=False)
        self.out = nn.Linear(graph_dim, 1)
        self.register_buffer("a_hat", self._build_adjacency())

    @staticmethod
    def _build_adjacency():
        # Node order: S, T, F1, F2, F3, F4, E, L.
        n = 8
        a = torch.zeros(n, n)
        edges = [(0, 1)]
        for f in range(2, 6):
            edges += [(0, f), (1, f), (f, 7)]
        edges += [(1, 6), (6, 7)]
        for i, j in edges:
            a[i, j] = 1
            a[j, i] = 1
        a += torch.eye(n)
        deg = a.sum(dim=1)
        d_inv = torch.diag(torch.pow(deg.clamp_min(1.0), -0.5))
        return d_inv @ a @ d_inv

    def forward(self, s_en, s_zh, factors, error_vec):
        b = s_en.size(0)
        nodes = [self.src_proj(s_en), self.tgt_proj(s_zh)]
        for i in range(4):
            nodes.append(self.factor_proj(factors[:, i : i + 1]))
        nodes.append(self.error_proj(error_vec))
        nodes.append(self.quality_seed.unsqueeze(0).expand(b, -1))
        h0 = torch.stack(nodes, dim=1)
        agg = torch.einsum("ij,bjd->bid", self.a_hat, h0)
        h1 = F.relu(self.gcn(agg))
        q_graph = torch.sigmoid(self.out(h1[:, 7])).squeeze(-1)
        return q_graph, h1
