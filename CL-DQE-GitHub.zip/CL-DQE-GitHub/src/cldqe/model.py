from __future__ import annotations

import torch
import torch.nn as nn

from .modules import MSCLEEncoder, ContrastiveProjector, ESA, LEA, MSQE, QualityGraph


class CLDQE(nn.Module):
    """CL-DQE implementation based on Sections 3-4 of the manuscript."""

    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        self.use_ccrl = cfg.get("use_ccrl", True)
        self.use_esa = cfg.get("use_esa", True)
        self.use_lea = cfg.get("use_lea", True)
        self.use_msqe = cfg.get("use_msqe", True)
        self.use_gqi = cfg.get("use_gqi", True)

        emb_dim = cfg["embedding_dim"]
        self.en_embedding = nn.Embedding(cfg["en_vocab_size"], emb_dim, padding_idx=0)
        self.zh_embedding = nn.Embedding(cfg["zh_vocab_size"], emb_dim, padding_idx=0)
        self.encoder = MSCLEEncoder(
            embedding_dim=emb_dim,
            gru_hidden=cfg["gru_hidden"],
            cnn_out_dim=cfg["cnn_out_dim"],
            downsample_factor=cfg["downsample_factor"],
            dropout=cfg["dropout"],
        )
        sent_dim = self.encoder.sent_dim
        seq_dim = self.encoder.seq_dim
        self.projector = ContrastiveProjector(sent_dim, cfg["contrastive_dim"], cfg["dropout"])
        self.esa = ESA(sent_dim, cfg["dropout"])
        self.lea = LEA(seq_dim, cfg["error_dim"], cfg["dropout"])
        msqe_in = sent_dim * 4 + cfg["error_dim"] + 2
        self.msqe = MSQE(msqe_in, cfg["dropout"])
        self.direct_q = nn.Sequential(nn.Linear(msqe_in, 256), nn.ReLU(), nn.Linear(256, 1))
        self.gqi = QualityGraph(sent_dim, cfg["error_dim"], cfg["graph_dim"])

    def encode(self, ids, mask, lang: str):
        emb = self.en_embedding(ids) if lang == "en" else self.zh_embedding(ids)
        return self.encoder(emb, mask)

    def forward(self, en_ids, zh_ids, en_mask=None, zh_mask=None):
        if en_mask is None:
            en_mask = (en_ids != 0).long()
        if zh_mask is None:
            zh_mask = (zh_ids != 0).long()

        en = self.encode(en_ids, en_mask, "en")
        zh = self.encode(zh_ids, zh_mask, "zh")
        z_en = self.projector(en["sent"])
        z_zh = self.projector(zh["sent"])

        u, align_prob, sim_score = self.esa(en["sent"], zh["sent"])
        if not self.use_esa:
            align_prob = torch.full_like(align_prob, 0.5)
            sim_score = torch.full_like(sim_score, 0.5)

        if self.use_lea:
            error_vec, attn = self.lea(en["fine_seq"], zh["fine_seq"], en_mask, zh_mask)
        else:
            error_vec = torch.zeros(
                en_ids.size(0), self.cfg["error_dim"], device=en_ids.device, dtype=en["sent"].dtype
            )
            attn = None

        q_features = torch.cat(
            [u, error_vec, align_prob.unsqueeze(-1), sim_score.unsqueeze(-1)], dim=-1
        )
        if self.use_msqe:
            factors, alpha, q_sent = self.msqe(q_features)
        else:
            q_sent = torch.sigmoid(self.direct_q(q_features)).squeeze(-1)
            factors = q_sent.unsqueeze(-1).expand(-1, 4)
            alpha = torch.full((4,), 0.25, device=q_sent.device)

        if self.use_gqi:
            q_graph, graph_states = self.gqi(en["sent"], zh["sent"], factors, error_vec)
        else:
            q_graph, graph_states = q_sent, None

        return {
            "s_en": en["sent"],
            "s_zh": zh["sent"],
            "z_en": z_en,
            "z_zh": z_zh,
            "align_prob": align_prob,
            "sim_score": sim_score,
            "error_vec": error_vec,
            "attention": attn,
            "factors": factors,
            "factor_weights": alpha,
            "q_sent": q_sent,
            "q_graph": q_graph,
            "graph_states": graph_states,
        }
