# Data

This repository does **not** redistribute PAWS-X or WMT20 QE data. Prepare the following local files:

```text
data/processed/
  pawsx_train.tsv   # src, tgt, align_label, sim_label
  pawsx_dev.tsv
  pawsx_test.tsv
  wmt20_train.tsv   # src, tgt, hter
  wmt20_dev.tsv
  wmt20_test.tsv
```

Use `scripts/prepare_pawsx.py` for the cross-language PAWS-X construction implemented in this repository and `scripts/prepare_wmt20.py` to convert official WMT20 source/MT/HTER text files.

Important: the manuscript states approximately 20k/2k/2k PAWS-X samples and 7k/1k/1k WMT20 samples, but it does not fully specify the exact PAWS-X English-Chinese pairing procedure or the exact WMT20 file release. Therefore the preparation scripts make those choices explicit rather than hiding them.
